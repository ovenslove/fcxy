<?php require_once  "headercode.php"; ?>
<style type="text/css" media="screen">
	.mainbox{
		border:1px solid #ccc;
	}
</style>
<h1 style="text-align: center; margin: 20px 0;">关于本站</h1>
<hr>

<div style="text-align: center;">
	<img src="../images/schoolpic/l4.jpg" alt="计通楼"  height="300px">
</div>

<p style="text-align: center;">本网站项目为湖南工业大学2015年毕业设计项目--<b style="font-size: 18px; color:blue;">基于PHP湖工大风彩校园</b>。</p>
<p>项目设计者:&nbsp;&nbsp;&nbsp;<b>刘文文</b>&nbsp;&nbsp;&nbsp;[湖南工业大学-计算机与通信学院-计算机科学与技术专业-1103班-学号-11408100318]。</p>
<p>指导导师：易德成导师</p>
<p>为了避免抄袭，现在此做出如下声明：</p>

<p>1：本项目由本人独立完成，其中所有核心代码为自己独立编写。</p>
<p>2：本项目中使用了部分GitHub开源插件：
<a href="http://fontawesome.dashgame.com/" title="fontawesome"  style="color:#93C6EA;">fontawesome图标库</a>、
<a href="http://fex.baidu.com/webuploader/" title="webuploader"  style="color:#93C6EA;">webuploader文件照片上传插件</a>、
<a href="http://kindeditor.net/demo.php" title="kindeditor" style="color:#93C6EA;">kindeditor在线富文本编辑器</a>等
</p>
<p>3：本项目使用<a href="http://www.sublimetext.com/3" title="Sublime Text 3"style="color:#93C6EA;">Sublime Text 3 </a>基于WAMP集成环境开发，GitHub项目地址：<a href="https://github.com/ovenslove/fcxy" title="湖工大风彩校园"style="color:#93C6EA;">湖工大风彩校园</a></p>
<p>4：本项目为开源项目，任何非盈利组织和个人都可以下载和修改源代码。</p>
<p>5：本项目传播和谐正能量，坚决抵制使用本网站发布任何黄赌毒等违法消息和色情图文视频，一经发现，封杀涉事账号和内容，并向公安机关报案。</p>
<p>6：本项目为毕业设计项目，个人能力有限，功能还不完善，安全级别较低，请各位大牛勿喷勿黑。</p>





<style type="text/css" media="screen">
	p{
		text-indent:4em;
		font-size:16px;
	}
</style>
<?php require_once  "footercode.php"; ?>