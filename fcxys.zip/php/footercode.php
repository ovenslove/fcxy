</div>
	<footer style="background: url('../images/footerback.png') no-repeat ; background-size: 100% 100%;" >
	<p align="center"style="color:white; margin: 10px 0; color: black; font-size: 16px;">湖南工业大学毕业设计项目-风彩校园</p>
	<p align="center" style="color:white; margin: 10px 0;color: black; font-size: 16px;">项目作者:刘文文 指导老师：易德成导师</p>
	<p align="center" style="color:white; margin: 10px 0;color: black; font-size: 16px;">项目时间：2015年4月-5月</p>
	</footer>
</body>
</html>