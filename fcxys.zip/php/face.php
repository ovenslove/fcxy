<?php require_once  "headercode.php"; ?>
<div style="width: 200px; height: 150px; border:1px solid #ccc; overflow: scroll;">
	<?php 
	for($i=1;$i<=130;$i++){
		echo "<img src='../images/facegif/".$i.".gif'>";
	}
 ?>
</div>



<?php require_once  "footercode.php"; ?>