<?php 

			$pages=$_POST['pages'];
			$limit=$_POST['limit'];
			$limitstar=$pages *$limit; 
			require_once '../php/mysqlcon.class.php';
	        $db=new mysqlcon();
		    $sql1="SELECT * FROM  `simpletalk` ORDER BY id  DESC limit {$limitstar},{$limit}";

	        $std1= $db->db_prepare($sql1);


	         if( $std1->execute()) {
	         		 $result=$std1->fetchall(PDO::FETCH_BOTH);
	         		 foreach ($result as $key => $value) {
	         		 	// var_dump($value);
	         		 	$value['addtime']=substr($value['addtime'],10,6);
	         		 	echo <<<oven
	         		 	<div class="simbox contentbox">
						<div  class="c_top_box">
						<a href="#"><img src="../images/logo.jpg" ></a><span><a href="#">{$value['username']}</a></span><br><span>{$value['addtime']}</span>
						</div>
						<div class="c_content_box">
							<div class="c_content_word">
								{$value['simpletalk']}
					
						</div>
						<div class="c_content_img">


oven;

	         		 	
	         		 	$sql2="SELECT * FROM  `images` WHERE  simpletalkid=".$value['simpletalkid'];
	         		 	$std2= $db->db_prepare($sql2);
	         		 	$std2->execute();
	         		 	$result2=$std2->fetchall(PDO::FETCH_BOTH);
	         		 	//var_dump($result2);
	         		 	 if(result2!=""){
							foreach ($result2 as $key2 => $value2) {
								         		 	 
								echo "<img src='".$value2['imgsrc']."'>";
								         		 	 	
							 }


	         		 	 }else{
	         		 	 	echo "暂无照片！";
	         		 	 }
	         		 	 
						
						echo <<<ovenslove
						</div>

</div>

			<div class="c_comment_add">
				<div class="c_comment_bar">
					<i class="fa fa-thumbs-o-up ">({$value['goodnum']}次)</i>
				</div>
				<div class="c_comment_show">
					<ul>
						<li><a href="#"><img src="../images/logo.jpg" ></a><span><a href="#">瓜瓜</a>：你好！</span><span>12:21</span></li>
						
						
					</ul>
					
				</div>
				<div style="position: relative;">
					<div class="c_comment" contenteditable="true">我也说一句</div>
					<input type="button" name="" value="评论">
				</div>
				
			</div>
		</div>



ovenslove;
						
						

	         		 }



	         }else {
	         	echo "faild";
	         }     




		 ?>