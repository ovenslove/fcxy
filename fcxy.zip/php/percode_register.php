<?php require_once  "headercode.php"; ?>

qq









<?php require_once  "footercode.php"; ?>