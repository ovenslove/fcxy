<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
	<title>风彩校园-湖南工业大学毕业设计</title>
	<script charset="utf-8" src="../kindeditor/kindeditor.js"></script>
    <script charset="utf-8" src="../kindeditor/lang/zh_CN.js"></script>
    <script type="text/javascript" src="../js/jquery-1.11.1.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/webmodle.base.css">
    </head>

<body>
	<header id="header" class="" style="text-align: center; line-height: 60px; font-size: 20px; font-weight: 700;">
			风彩校园-湖南工业大学毕业设计
	</header><!-- /header -->

	<div class="mainbox" >