<?php session_start(); ?>


<?php 

$username=$_POST['username'];

$_SESSION['username']=$username;

 if(isset($_SESSION['username'])){
        	echo 'true';
        }else{
        	echo 'false';
        }

 ?>