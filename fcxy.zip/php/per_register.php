<?php require_once  "headercode.php"; ?>
<style type="text/css" >
	.reg_box_map{height:400px; width:100%;  position: absolute; margin-top:10px;}
</style>
<div class="reg_box" style=" min-height: 500px; background: #98E7DE; width: 100%; position: relative;" >
	<span>注册进度</span><progress value="20" max="100"></progress>
	<div class="reg_box_map" style=" background: #F36E6E; z-index: 100;">
		
	</div>

	<div class="reg_box_map" style=" background: #F05CEC; z-index: 99;">
		
	</div>

	<div class="reg_box_map" style=" background: #F6EF6E; z-index: 98;">
		
	</div>
</div>

<?php require_once  "footercode.php"; ?>